class ComputerPlayer

  def initialize
    @known_cards = {}
    @mathed_cards = nil
  end

  def player_guess
  end

  def receive_revealed_card
  end

  def receive_match
  end

end
